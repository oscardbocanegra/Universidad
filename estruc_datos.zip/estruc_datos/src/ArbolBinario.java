import java.util.ArrayList;

public class ArbolBinario {
    //La siguiente linea indica la raiz por la cual en nodo va a arrancar
    Nodo raiz;

    //Creamos el constructor para indicar que nuestra raiz va a arrancar en un valor nulo
    public ArbolBinario(){
        raiz=null;
    }

    //Metodo para insertar un nodo en el arbol
    public void agregarNodo(int d, String nom){
        Nodo nuevo = new Nodo(d, nom);
        //En el siguiente condicional lo que vamos a hacer es evaluar si la raiz
        //tiene un valor nulo y si esto es asi vamos a agregar el nuevo Nodo creado anteriormente.
        if (raiz == null){
            raiz=nuevo;
        }else {
            //Creamos un Nodo auxiliar que va a estar apuntando a la raiz
            Nodo auxiliar = raiz;
            Nodo padre;
            while (true){
                padre=auxiliar;
                //En el siguiente condicional estamos indicando si el dato es menor al auxiliar
                //este dato se debe de ubicar hacia la izquierda
                if (d< auxiliar.dato){
                    auxiliar=auxiliar.izq;
                    //Aca indicamos que cuando el dato anterior encuentre el null en la rama de la
                    //izquierda lo vamos a ubicar en ese lugar
                    if (auxiliar==null){
                        padre.izq=nuevo;
                        return;
                    }
                 //En el siguiente else indicamos lo contrario que seria cuando el nodo debe de ubicarse
                 //hacia la derecha del nodo padre
                }else {
                    auxiliar=auxiliar.der;
                    if (auxiliar==null){
                        padre.der=nuevo;
                        return;
                    }
                }
            }
        }
    }
    //Metodo para saber cuando el arbol esta vacio
    public boolean estaVacio(){
    return raiz ==null;
        }


    //Metodo para recorrer el Arbol InOrden en el cual como parametro le vamos a pasar la raiz del arbol
    public void inOrden(Nodo r){
        //En la siguiente condicion lo que vamos a hacer es recorrer el subarbol izquierdo InOrden
            if (r!=null){
                inOrden(r.izq);
                System.out.print(r.dato + ", ");
                inOrden(r.der);
            }
        }
    //Metodo para recorrer el Arbol PreOrden
    public void preOrden(Nodo raiz){
        if (raiz!=null){
            System.out.print(raiz.dato + ", ");
            preOrden(raiz.izq);
            preOrden(raiz.der);
        }
    }

    //Metodo para recorrer el Arbol PostOrden
    public void postOrden(Nodo raiz){
        if (raiz!=null){
            postOrden(raiz.izq);
            postOrden(raiz.der);
            System.out.print(raiz.dato + ", ");
        }
    }
    //Metodo para eliminar un Nodo del arbol
    public boolean eliminar(int d){
        Nodo auxiliar=raiz;
        Nodo padre=raiz;
        boolean esHijoIzq=true;

        //Con el siguiente while lo que vamos a hacer es nodo a eliminar
        while (auxiliar.dato!=d){
            padre=auxiliar;
            //En la siguiente condicion lo que vamos a hacer es indicar que
            //si d es menor a auxiliar de dato vamos a mandar al dato por la izquierda
            if (d<auxiliar.dato){
                esHijoIzq=true;
                auxiliar=auxiliar.izq;
            }else {
                esHijoIzq=false;
                auxiliar=auxiliar.der;
            }
            if (auxiliar == null){
                return false;
            }
        }//Fin del while
        //Cuando se cumple la siguiente condicion lo que quiere decir que es un nodo oja o solo tenemos la raiz
        if (auxiliar.izq ==null && auxiliar.der==null){
            if (auxiliar==raiz){
                raiz=null;
            }else if (esHijoIzq){
                padre.izq=null;
            }else {
                padre.der=null;
            }
        }else if (auxiliar.der==null){
            if (auxiliar==raiz){
                raiz=auxiliar.izq;
            }else if (esHijoIzq){
                padre.izq=auxiliar.izq;
            }else {
                padre.der=auxiliar.izq;
            }
        } else if (auxiliar.izq==null) {
            if (auxiliar==raiz){
                raiz=auxiliar.der;
            }else if (esHijoIzq){
                padre.izq=auxiliar.der;
            }else {
                padre.der=auxiliar.izq;
            }
        }else {
            Nodo reemplazo = obtenerNodoReemplazo(auxiliar);
            if (auxiliar==raiz){
                raiz=reemplazo;
            } else if (esHijoIzq) {
                padre.izq=reemplazo;
            }else {
                padre.der=reemplazo;
            }
            reemplazo.izq=auxiliar.izq;
        }
        return true;
    }
    //Metodo encargado de devolvernos el nodo reemplazo
    public Nodo obtenerNodoReemplazo(Nodo nodoReemp){
        Nodo reemplazarPadre=nodoReemp;
        Nodo reemplazo=nodoReemp;
        Nodo auxiliar = nodoReemp.der;
        while (auxiliar!=null){
            reemplazarPadre=reemplazo;
            reemplazo=auxiliar;
            auxiliar=auxiliar.izq;
        }
        if (reemplazo!=nodoReemp.der){
            reemplazarPadre.izq=reemplazo.der;
            reemplazo.der = nodoReemp.der;
        }
        System.out.println("El Nodo Reemplazo es " + reemplazo);
        return reemplazo;
    }

}



public class Nodo {
    int dato;

    //Con este String lo que estamos haciendo es ponerle nombre al nodo
    String nombre;
    //En el siguiente parametro lo que estamos haciendo es crear nuestros nodos punteros
    Nodo izq, der;

    //A continucion creamos el constructor el cual va a ser el encargado de darle vida al nodo
    public Nodo(int d, String nom){
        this.dato = d;
        this.nombre = nom;

        //Los nodos punteros los vamos a iniciar con un valor de null ya que cada que se cree un
        //Nodo sus hijos no van a tener ningun valor
        this.izq = null;
        this.der = null;
    }


    //Aca lo que estamos haciendo es permitirnos mostrar la informacion que tenemos en nuestro objeto
    public String toString(){
        return nombre + " Su dato es " + dato;
    }

}

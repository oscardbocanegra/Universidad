import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        int opcion =0, elemento;
        String nombre;
        ArbolBinario arbolito = new ArbolBinario();
        do {
            try {
                opcion = Integer.parseInt(JOptionPane.showInputDialog(null,
                        "1. Agregar un nodo\n" +
                                "2. Imprimir elementos\n" +
                                "3. Eliminar una Nodo del Arbol\n"+
                                "4. Salir\n" +
                                "Elige una opcion", "Arboles Binarios", JOptionPane.QUESTION_MESSAGE));

                switch (opcion){
                    case 1:
                        elemento = Integer.parseInt(JOptionPane.showInputDialog(null,
                                "Ingresa el numero del Nodo", "Agregando Nodo",
                                JOptionPane.QUESTION_MESSAGE));
                        nombre = JOptionPane.showInputDialog(null,
                                "ingresa el nombre del Nodo", "Agregando Nodo",
                                JOptionPane.QUESTION_MESSAGE);
                        arbolito.agregarNodo(elemento, nombre );
                        break;
                    case 2:
                        if (!arbolito.estaVacio()){
                            arbolito.inOrden(arbolito.raiz);
                        }else {
                            JOptionPane.showMessageDialog(null,"ELarbol esta vacio",
                                    "Cuidado", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 3:
                        if (!arbolito.estaVacio()){
                            elemento = Integer.parseInt(JOptionPane.showInputDialog(null,
                                    "Ingresa el numero del Nodo a eliminar", "Eliminar Nodo", JOptionPane.QUESTION_MESSAGE));

                            if (arbolito.eliminar(elemento)==false){
                                JOptionPane.showMessageDialog(null,"El Nodo no se encuentra en el arbol",
                                        "Nodo no encontrado", JOptionPane.INFORMATION_MESSAGE);
                            }else {
                                JOptionPane.showMessageDialog(null,"El Nodo ha sido eliminado del arbol",
                                        "Nodo Eliminado", JOptionPane.INFORMATION_MESSAGE);
                            }
                        }else {
                            JOptionPane.showMessageDialog(null, "El Arbol Esta Vacio",
                                    "Cuidado", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 4:
                        JOptionPane.showMessageDialog(null, "Aplicacion Finalizada",
                                "Fin", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Opcion Incorrecta",
                                "Cuidado", JOptionPane.INFORMATION_MESSAGE);
                }
            }catch (NumberFormatException n){
                JOptionPane.showMessageDialog(null, "Error " + n.getMessage());
            }
        }while (opcion!=4);
    }
}
class CertificadoDeAhorroTerminoFijo extends ProductoBancario implements ProductoBancarioInterfaz{

    private int numeroMeses;
    private double valor;
    private double interesMensual;

    public CertificadoDeAhorroTerminoFijo(Cliente cliente, int numeroProducto, double saldo, int numeroMeses,
                                          double valor, double interesMensual, String fechaApertura){

        super(cliente, numeroProducto,saldo, fechaApertura);
        this.numeroMeses = numeroMeses;
        this.valor = valor;
        this.interesMensual = interesMensual;
    }


    @Override
    public double calcularIntereses() {
        double intereses = valor * numeroMeses * interesMensual;
        return saldo += intereses;  
    }

    @Override
    public void depositar(double cantidad) {
        if (cantidad > 0){
            saldo += cantidad;
        }
    }

    @Override
    public void retirar(double cantidad) {
        if (saldoDisponible(cantidad)){
            saldo -= cantidad;
        }
    }

    @Override
    public boolean saldoDisponible(double cantidad) {
        return saldo >= cantidad;
    }
}

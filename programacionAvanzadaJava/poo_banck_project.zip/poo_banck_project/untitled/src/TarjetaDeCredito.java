class TarjetaDeCredito extends ProductoBancario implements ProductoBancarioInterfaz{

    private String fechaVencimiento;
    private double interesPorUso;
    private double cupo;
    private double valorUtilizado;

    public TarjetaDeCredito(Cliente cliente, int numeroProducto, double saldo, String fechaVencimiento, double interesPorUso, double cupo, double valorUtilizado,String fechaApertura) {
        super(cliente, numeroProducto, saldo, fechaApertura);
        this.fechaVencimiento = fechaVencimiento;
        this.interesPorUso = interesPorUso;
        this.cupo = cupo;
        this.valorUtilizado = valorUtilizado;
    }

    @Override
    public double calcularIntereses() {
        double intereses = valorUtilizado * interesPorUso;
        return saldo += intereses;
    }

    @Override
    public void depositar(double cantidad) {
        if (cantidad > 0){
            saldo += cantidad;
        }
    }

    @Override
    public void retirar(double cantidad) {
        if (saldoDisponible(cantidad)){
            saldo -= cantidad;
        }
    }

    @Override
    public boolean saldoDisponible(double cantidad) {
        return false;
    }
}

public interface ProductoBancarioInterfaz {
    void depositar(double cantidad);
    void retirar(double cantidad);
    boolean saldoDisponible(double cantidad);
}

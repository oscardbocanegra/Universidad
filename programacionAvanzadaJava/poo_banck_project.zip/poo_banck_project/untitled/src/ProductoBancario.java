abstract class ProductoBancario {

    protected Cliente cliente;
    protected int numeroProducto;
    protected double saldo;

    protected String fechaApertura;

    public ProductoBancario(Cliente cliente, int numeroProducto, double saldo, String fechaApertura) {
        this.cliente = cliente;
        this.numeroProducto = numeroProducto;
        this.saldo = saldo;
        this.fechaApertura = fechaApertura;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public int getNumeroProducto() {
        return numeroProducto;
    }

    public void setNumeroProducto(int numeroProducto) {
        this.numeroProducto = numeroProducto;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public String getFechaApertura() {
        return fechaApertura;
    }

    public void setFechaApertura(String fechaApertura) {
        this.fechaApertura = fechaApertura;
    }

    public abstract double calcularIntereses();
}

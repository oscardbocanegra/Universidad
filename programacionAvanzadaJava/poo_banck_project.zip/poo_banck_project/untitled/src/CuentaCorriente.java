class CuentaCorriente extends ProductoBancario implements ProductoBancarioInterfaz{

    private double porcentajeInteres;
    private double valorSobregiro;

    public CuentaCorriente (Cliente cliente, int numeroProducto, double saldo, double porcentajeInteres, double valorSobregiro, String fechaApertura){

        super(cliente, numeroProducto, saldo, fechaApertura);
        this.porcentajeInteres = porcentajeInteres;
        this.valorSobregiro = valorSobregiro;
    }


    @Override
    public double calcularIntereses() {
        double intereses = saldo * porcentajeInteres;
        return saldo += intereses;
    }


    @Override
    public void depositar(double cantidad) {
        if (cantidad > 0){
            saldo += cantidad;
        }
    }

    @Override
    public void retirar(double cantidad) {
        if (saldoDisponible(cantidad)){
            saldo -= cantidad;
        }
    }

    @Override
    public boolean saldoDisponible(double cantidad) {
        return saldo >= cantidad;
    }
}

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner consola = new Scanner(System.in);

        int option = 0;

        do {
            System.out.println("1. CUENTA DE AHORROS");
            System.out.println("2. CUENTA CORRIENTE");
            System.out.println("3. CERTIFICADO DE INTERES FIJO");
            System.out.println("4. TARJETA DE CREDITO");
            System.out.println("5. Salir");
            option = consola.nextInt();

            switch (option){
                case 1:
                    Cliente cliente1 = new Cliente("123456789", "Juan Perez", "juan@example.com", "123-456-7890", "123 Calle Principal");
                    CuentaDeAhorro cuentaAhorro = new CuentaDeAhorro(cliente1, 1, 1000.0, 0.05, "12/7/2030");
                    System.out.println("-------------------");
                    System.out.println("Cliente: " + cliente1.getNombre()+"\nDocumento: "+cliente1.getDocumentoIdentidad()+ "\nEmail: "+cliente1.getCorreoElectronico());
                    System.out.println("Producto: CUENTA DE AHORROS"+ "\nNumero producto: "+cuentaAhorro.getNumeroProducto()+"\nFecha apertura: "+cuentaAhorro.getFechaApertura());
                    System.out.println("Saldo + intereses: " + cuentaAhorro.getSaldo());
                    System.out.println("Interes: "+cuentaAhorro.calcularIntereses());
                case 2:
                    Cliente cliente2 = new Cliente("123454321", "David Rodriguez", "david@example.com", "123-654-3456", "34-56sur");
                    CuentaCorriente cuentaCorriente = new CuentaCorriente(cliente2, 2, 2000.0, 0.03, 500.0, "12/7/2030");
                    System.out.println("-------------------");
                    System.out.println("Cliente: " + cliente2.getNombre()+"\nDocumento: "+cliente2.getDocumentoIdentidad()+ "\nEmail: "+cliente2.getCorreoElectronico());
                    System.out.println("Producto: CUENTA DE AHORROS"+ "\nNumero producto: "+cuentaCorriente.getNumeroProducto()+"\nFecha apertura: "+cuentaCorriente.getFechaApertura());
                    System.out.println("Saldo: " + cuentaCorriente.getSaldo());
                    System.out.println("Saldo + Interes: "+cuentaCorriente.calcularIntereses());

                case 3:
                    Cliente cliente3 = new Cliente("98764325", "Juan Perez", "juan@example.com", "456-654-4389", "78-45 norte");
                    CertificadoDeAhorroTerminoFijo cdt = new CertificadoDeAhorroTerminoFijo(cliente3, 3, 5000.0, 12, 5000.0, 0.08, "12/7/2030");
                    System.out.println("-------------------");
                    System.out.println("Cliente: " + cliente3.getNombre()+"\nDocumento: "+cliente3.getDocumentoIdentidad()+ "\nEmail: "+cliente3.getCorreoElectronico());
                    System.out.println("Producto: CDT"+ "\nNumero producto: "+cdt.getNumeroProducto()+"\nFecha apertura: "+cdt.getFechaApertura());
                    System.out.println("Saldo: " + cdt.getSaldo());
                    System.out.println("Saldo + Interes: "+cdt.calcularIntereses());

                case 4:
                    Cliente cliente4 = new Cliente("45673245", "Fernando Paez", "fernando@example.com", "768-476-3479", "87-45 oeste");
                    TarjetaDeCredito tarjetaCredito = new TarjetaDeCredito(cliente4, 4, 10000.0, "01/2025", 0.1, 5000.0, 2000.0, "12/7/2030");
                    System.out.println("-------------------");
                    System.out.println("Cliente: " + cliente4.getNombre()+"\nDocumento: "+cliente4.getDocumentoIdentidad()+ "\nEmail: "+cliente4.getCorreoElectronico());
                    System.out.println("Producto: Tarjeta Credito"+ "\nNumero producto: "+tarjetaCredito.getNumeroProducto()+"\nFecha apertura: "+tarjetaCredito.getFechaApertura());
                    System.out.println("Saldo: " + tarjetaCredito.getSaldo());
                    System.out.println("Saldo + Interes: "+tarjetaCredito.calcularIntereses());

            }
            System.out.println("---------------------------");

        }while (option != 5);
    }

}

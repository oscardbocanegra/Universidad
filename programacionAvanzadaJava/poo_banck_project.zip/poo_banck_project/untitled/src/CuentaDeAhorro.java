class CuentaDeAhorro extends ProductoBancario implements ProductoBancarioInterfaz{

    private double porcentajeInteres;

    public CuentaDeAhorro(Cliente cliente, int numeroProducto, double saldo, double porcentajeInteres, String fechaApertura) {
        super(cliente, numeroProducto, saldo, fechaApertura);
        this.porcentajeInteres = porcentajeInteres;
    }

    @Override
    public double calcularIntereses() {
        double intereses = saldo * porcentajeInteres;
        return saldo += intereses;
    }

    @Override
    public void depositar(double cantidad) {
        if (cantidad > 0){
            saldo += cantidad;
        }
    }

    @Override
    public void retirar(double cantidad) {
        if (saldoDisponible(cantidad)){
            saldo -= cantidad;
        }
    }

    @Override
    public boolean saldoDisponible(double cantidad) {
        return saldo >= cantidad;
    }
}

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FarmaciaApp {
    private JFrame frame;
    private JTextField nombreMedicamentoField;
    private JComboBox<String> tipoMedicamentoComboBox;
    private JTextField cantidadField;
    private ButtonGroup distribuidorGroup;
    private JCheckBox principalCheckBox;
    private JCheckBox secundariaCheckBox;

    public FarmaciaApp() {
        frame = new JFrame("Sistema de Pedidos de Medicamentos");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(7, 2));

        JLabel lblNombreMedicamento = new JLabel("Nombre del Medicamento:");
        nombreMedicamentoField = new JTextField();
        JLabel lblTipoMedicamento = new JLabel("Tipo del Medicamento:");
        tipoMedicamentoComboBox = new JComboBox<>(new String[]{"Analgésico", "Analéptico",
                "Anestésico", "Antiácido", "Antidepresivo", "Antibiótico"});
        JLabel lblCantidad = new JLabel("Cantidad de Producto:");
        cantidadField = new JTextField();
        JLabel lblDistribuidor = new JLabel("Distribuidor Farmacéutico:");
        JPanel distribuidorPanel = new JPanel();
        distribuidorGroup = new ButtonGroup();
        JRadioButton cofarmaRadio = new JRadioButton("Cofarma");
        JRadioButton empsepharRadio = new JRadioButton("Empsephar");
        JRadioButton cemefarRadio = new JRadioButton("Cemefar");
        distribuidorGroup.add(cofarmaRadio);
        distribuidorGroup.add(empsepharRadio);
        distribuidorGroup.add(cemefarRadio);
        distribuidorPanel.add(cofarmaRadio);
        distribuidorPanel.add(empsepharRadio);
        distribuidorPanel.add(cemefarRadio);

        JLabel lblSucursal = new JLabel("Sucursal de la Farmacia:");
        JPanel sucursalPanel = new JPanel();
        principalCheckBox = new JCheckBox("Principal");
        secundariaCheckBox = new JCheckBox("Secundaria");
        sucursalPanel.add(principalCheckBox);
        sucursalPanel.add(secundariaCheckBox);

        JButton btnBorrar = new JButton("Borrar");
        JButton btnConfirmar = new JButton("Confirmar");

        panel.add(lblNombreMedicamento);
        panel.add(nombreMedicamentoField);
        panel.add(lblTipoMedicamento);
        panel.add(tipoMedicamentoComboBox);
        panel.add(lblCantidad);
        panel.add(cantidadField);
        panel.add(lblDistribuidor);
        panel.add(distribuidorPanel);
        panel.add(lblSucursal);
        panel.add(sucursalPanel);
        panel.add(btnBorrar);
        panel.add(btnConfirmar);

        frame.add(panel);
        frame.setVisible(true);

        btnBorrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                nombreMedicamentoField.setText("");
                tipoMedicamentoComboBox.setSelectedIndex(0);
                cantidadField.setText("");
                distribuidorGroup.clearSelection();
                principalCheckBox.setSelected(false);
                secundariaCheckBox.setSelected(false);
            }
        });

        btnConfirmar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombreMedicamento = nombreMedicamentoField.getText();
                String tipoMedicamento = (String) tipoMedicamentoComboBox.getSelectedItem();
                String cantidad = cantidadField.getText();
                String distribuidor = "";
                if (cofarmaRadio.isSelected()) {
                    distribuidor = "Cofarma";
                } else if (empsepharRadio.isSelected()) {
                    distribuidor = "Empsephar";
                } else if (cemefarRadio.isSelected()) {
                    distribuidor = "Cemefar";
                }
                String sucursal = "";
                if (principalCheckBox.isSelected() && secundariaCheckBox.isSelected()) {
                    sucursal = "Principal y Secundaria";
                } else if (principalCheckBox.isSelected()) {
                    sucursal = "Principal";
                } else if (secundariaCheckBox.isSelected()) {
                    sucursal = "Secundaria";
                }

                if (nombreMedicamento.isEmpty() || tipoMedicamento.isEmpty() || cantidad.isEmpty() || distribuidor.isEmpty() || sucursal.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Por favor, complete todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    mostrarResumenPedido(nombreMedicamento, tipoMedicamento, cantidad, distribuidor, sucursal);
                }
            }
        });
    }

    private void mostrarResumenPedido(String nombreMedicamento, String tipoMedicamento, String cantidad, String distribuidor, String sucursal) {
        JFrame resumenFrame = new JFrame("Pedido al distribuidor " + distribuidor);
        resumenFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        resumenFrame.setSize(400, 200);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 1));

        JLabel lblPedido = new JLabel("Pedido al distribuidor " + distribuidor);
        JLabel lblMedicamento = new JLabel(cantidad + " unidades del " + tipoMedicamento + " " + nombreMedicamento);
        JLabel lblDireccion = new JLabel("Para la farmacia situada en " + obtenerDireccionFarmacia(sucursal));

        JButton btnCancelar = new JButton("Cancelar");
        JButton btnEnviar = new JButton("Enviar Pedido");

        panel.add(lblPedido);
        panel.add(lblMedicamento);
        panel.add(lblDireccion);
        panel.add(btnCancelar);
        panel.add(btnEnviar);

        resumenFrame.add(panel);
        resumenFrame.setVisible(true);

        btnCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resumenFrame.dispose();
            }
        });

        btnEnviar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Pedido enviado");
                resumenFrame.dispose();
            }
        });
    }
    
    private String obtenerDireccionFarmacia(String sucursal) {
        if (sucursal.equals("Principal")) {
            return "Calle de la Rosa n. 28";
        } else if (sucursal.equals("Secundaria")) {
            return "Calle Alcazabilla n. 3";
        } else {
            return "Calle de la Rosa n. 28 y Calle Alcazabilla n. 3";
        }
    }
}